# Nature Soap - เว็บสั่งซื้อสบู่

## วิธีตั้งค่า Google Sheets
1. สร้าง Google Sheets ใหม่ ตั้งชื่อคอลัมน์แถวที่ 1: `id`, `name`, `price`, `image`, `description`
2. กรอกข้อมูลสินค้าอย่างน้อย 2 SKU ในแถวถัดไป
3. ไปที่ **ไฟล์ (File) > แชร์ (Share) > เผยแพร่ไปยังเว็บ (Publish to web)**
4. เลือกชีตและเปลี่ยนรูปแบบเป็น **Comma-separated values (.csv)** แล้วกดเผยแพร่
5. นำลิงก์ CSV ที่ได้ไปวางในตัวแปร `SHEET_CSV_URL` ในไฟล์ `script.js`

## วิธี Deploy ขึ้น Vercel ผ่าน GitHub
1. แตกไฟล์ ZIP นี้และอัปโหลดไฟล์ทั้งหมด (`index.html`, `style.css`, `script.js`) ขึ้น GitHub Repository
2. เข้าสู่ระบบ [Vercel](https://vercel.com/) กด **Add New... > Project**
3. เลือก Repository ที่สร้างไว้ แล้วกด **Deploy** ได้ทันที
