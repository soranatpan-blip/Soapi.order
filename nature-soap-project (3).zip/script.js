// 1. วางลิงก์ Google Sheets (Publish to web -> CSV) ของคุณที่นี่
const SHEET_CSV_URL = "วางลิงก์_CSV_จาก_GOOGLE_SHEETS_ที่นี่";

// ข้อมูลสำรอง (Fallback) กรณียังไม่ได้ใส่ลิงก์ Google Sheets
const FALLBACK_PRODUCTS = [
    {
        id: "SOAP-01",
        name: "สบู่สมุนไพรขมิ้นชันน้ำผึ้ง",
        price: 89,
        image: "https://images.unsplash.com/photo-1600857062241-98e5dba7f214?auto=format&fit=crop&w=500&q=80",
        description: "ช่วยให้ผิวกระจ่างใส ลดการอักเสบของสิวอย่างอ่อนโยน"
    },
    {
        id: "SOAP-02",
        name: "สบู่สครับกาแฟอาราบิก้า",
        price: 120,
        image: "https://images.unsplash.com/photo-1607006344380-b6775a0824a7?auto=format&fit=crop&w=500&q=80",
        description: "ผลัดเซลล์ผิวเก่า เผยผิวเนียนนุ่มชุ่มชื้นทันทีหลังอาบน้ำ"
    }
];

let products = [];
let cart = [];

// อ้างอิง DOM Elements
const productListEl = document.getElementById("product-list");
const loadingEl = document.getElementById("loading");
const cartModal = document.getElementById("cart-modal");
const openCartBtn = document.getElementById("open-cart-btn");
const closeCartBtn = document.getElementById("close-cart-btn");
const cartItemsEl = document.getElementById("cart-items");
const cartCountEl = document.getElementById("cart-count");
const cartTotalEl = document.getElementById("cart-total");
const checkoutBtn = document.getElementById("checkout-btn");

// ฟังก์ชันแปลงข้อมูล CSV เป็น Array of Objects
function parseCSV(csvText) {
    const lines = csvText.trim().split("\n");
    const headers = lines[0].split(",").map(h => h.trim().replace(/^"|"$/g, ''));
    const result = [];

    for (let i = 1; i < lines.length; i++) {
        // รองรับกรณีมีลูกน้ำ (,) อยู่ในเครื่องหมายคำพูด "..."
        const values = lines[i].split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
        if (values.length >= 4) {
            const obj = {};
            headers.forEach((header, index) => {
                let val = values[index] ? values[index].trim().replace(/^"|"$/g, '') : "";
                obj[header] = header === "price" ? parseFloat(val) || 0 : val;
            });
            result.push(obj);
        }
    }
    return result;
}

// ดึงข้อมูลสินค้าจาก Google Sheets
async function fetchProducts() {
    try {
        if (!SHEET_CSV_URL.startsWith("http")) {
            throw new Error("ยังไม่ได้ตั้งค่า URL ของ Google Sheets");
        }
        const response = await fetch(SHEET_CSV_URL);
        if (!response.ok) throw new Error("โหลดข้อมูลไม่สำเร็จ");
        const csvText = await response.text();
        products = parseCSV(csvText);
    } catch (error) {
        console.warn("ใช้ข้อมูลสินค้าสำรอง:", error.message);
        products = FALLBACK_PRODUCTS;
    } finally {
        loadingEl.style.display = "none";
        renderProducts();
    }
}

// แสดงรายการสินค้าบนหน้าเว็บ
function renderProducts() {
    productListEl.innerHTML = products.map(product => `
        <div class="product-card">
            <img src="${product.image}" alt="${product.name}" class="product-img" onerror="this.src='https://via.placeholder.com/300x220?text=No+Image'">
            <div class="product-info">
                <h3 class="product-title">${product.name}</h3>
                <p class="product-desc">${product.description || ""}</p>
                <div class="product-bottom">
                    <span class="product-price">${product.price.toLocaleString()} ฿</span>
                    <button class="add-btn" onclick="addToCart('${product.id}')">+ เพิ่มลงตะกร้า</button>
                </div>
            </div>
        </div>
    `).join("");
}

// เพิ่มสินค้าลงตะกร้า
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const existingItem = cart.find(item => item.id === productId);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ ...product, quantity: 1 });
    }
    updateCartUI();
}

// ปรับจำนวนสินค้าในตะกร้า
function changeQuantity(productId, delta) {
    const itemIndex = cart.findIndex(item => item.id === productId);
    if (itemIndex === -1) return;

    cart[itemIndex].quantity += delta;
    if (cart[itemIndex].quantity <= 0) {
        cart.splice(itemIndex, 1);
    }
    updateCartUI();
}

// อัปเดตการแสดงผลตะกร้าและคำนวณราคารวม
function updateCartUI() {
    const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    cartCountEl.textContent = totalCount;
    cartTotalEl.textContent = totalPrice.toLocaleString();

    if (cart.length === 0) {
        cartItemsEl.innerHTML = `<p style="text-align:center; color:#888; padding: 20px;">ยังไม่มีสินค้าในตะกร้า</p>`;
        return;
    }

    cartItemsEl.innerHTML = cart.map(item => `
        <div class="cart-item">
            <div class="cart-item-info">
                <h4>${item.name}</h4>
                <p>${item.price.toLocaleString()} บาท x ${item.quantity} = ${(item.price * item.quantity).toLocaleString()} บาท</p>
            </div>
            <div class="cart-controls">
                <button class="qty-btn" onclick="changeQuantity('${item.id}', -1)">-</button>
                <span>${item.quantity}</span>
                <button class="qty-btn" onclick="changeQuantity('${item.id}', 1)">+</button>
            </div>
        </div>
    `).join("");
}

// เปิด-ปิด หน้าต่างตะกร้า
openCartBtn.addEventListener("click", () => {
    updateCartUI();
    cartModal.classList.remove("hidden");
});

closeCartBtn.addEventListener("click", () => {
    cartModal.classList.add("hidden");
});

// กดปุ่มสั่งซื้อ
checkoutBtn.addEventListener("click", () => {
    if (cart.length === 0) {
        alert("กรุณาเลือกสินค้าลงตะกร้าก่อนสั่งซื้อครับ");
        return;
    }

    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const orderSummary = cart.map(item => `- ${item.name} (${item.quantity} ชิ้น)`).join("\n");

    alert(`🎉 สั่งซื้อสำเร็จ!\n\nรายการสั่งซื้อ:\n${orderSummary}\n\nยอดชำระทั้งหมด: ${totalPrice.toLocaleString()} บาท\nขอบคุณที่อุดหนุนครับ!`);
    
    // ล้างตะกร้าและปิดหน้าต่าง
    cart = [];
    updateCartUI();
    cartModal.classList.add("hidden");
});

// เริ่มทำงานเมื่อโหลดหน้าเว็บ
fetchProducts();
